# Scroll-driven business presentation

A 15-scene, scroll-led presentation built with React, TypeScript, Vite, and Three.js. The supplied GLB stays in one persistent 3D scene while the camera, lighting, and model turntable respond to the reader's progress.

## Run locally

Requires Node.js.

```sh
npm install
npm run dev
```

The site opens at `http://localhost:3000`. To type-check and create a production build:

```sh
npm run lint
npm run build
```

## Experience structure

- `src/App.tsx` tracks the active scene and provides keyboard and scroll navigation.
- `src/components/ScrollStory.tsx` defines the 15 scenes, interactive service tiles, and project detail dialogs.
- `src/components/Navigation.tsx` provides scene progress, previous/next controls, and section shortcuts.
- `src/components/RobotScene/RobotCanvas.tsx` owns the persistent GLB scene, model loading, camera path, and scroll-responsive lighting.
- `public/models/protector_nemesis__the_fallen_seraph.glb` is the robot asset.

The GLB contains no animation clips. Its camera, lighting, and restrained turntable motion are synchronized to scroll; it does not perform walking or rigged gestures. The showcase text avoids claiming commercial deployment or client results for the listed projects.
