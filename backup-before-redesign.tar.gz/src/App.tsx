import React, { useCallback, useEffect, useState } from 'react';
import { RobotCanvas } from './components/RobotScene/RobotCanvas';
import { Navigation } from './components/Navigation';
import { ScrollStory, PRESENTATION_SCENES } from './components/ScrollStory';

export default function App() {
  const [activeScene, setActiveScene] = useState(0);

  const navigateToScene = useCallback((sceneIndex: number) => {
    const target = document.getElementById(`scene-${PRESENTATION_SCENES[sceneIndex]?.id}`);
    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  useEffect(() => {
    let frameId = 0;
    const updateActiveScene = () => {
      cancelAnimationFrame(frameId);
      frameId = requestAnimationFrame(() => {
        const viewportCenter = window.innerHeight * 0.48;
        const sections = document.querySelectorAll<HTMLElement>('[data-scene-index]');
        let closestIndex = 0;
        let closestDistance = Number.POSITIVE_INFINITY;
        sections.forEach((section) => {
          const bounds = section.getBoundingClientRect();
          const distance = Math.abs(bounds.top + bounds.height / 2 - viewportCenter);
          if (distance < closestDistance) {
            closestDistance = distance;
            closestIndex = Number(section.dataset.sceneIndex);
          }
        });
        setActiveScene((previous) => previous === closestIndex ? previous : closestIndex);
      });
    };

    window.addEventListener('scroll', updateActiveScene, { passive: true });
    window.addEventListener('resize', updateActiveScene);
    updateActiveScene();
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('scroll', updateActiveScene);
      window.removeEventListener('resize', updateActiveScene);
    };
  }, []);

  useEffect(() => {
    const handleKeyboardNavigation = (event: KeyboardEvent) => {
      if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
      const target = event.target;
      if (document.querySelector('[role="dialog"][aria-modal="true"]')) return;
      if (
        target instanceof HTMLElement &&
        (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'A'].includes(target.tagName))
      ) return;

      if (event.key === 'PageDown' || event.key === 'ArrowDown') {
        event.preventDefault();
        navigateToScene(Math.min(activeScene + 1, PRESENTATION_SCENES.length - 1));
      } else if (event.key === 'PageUp' || event.key === 'ArrowUp') {
        event.preventDefault();
        navigateToScene(Math.max(activeScene - 1, 0));
      } else if (event.key === 'Home') {
        event.preventDefault();
        navigateToScene(0);
      } else if (event.key === 'End') {
        event.preventDefault();
        navigateToScene(PRESENTATION_SCENES.length - 1);
      }
    };

    window.addEventListener('keydown', handleKeyboardNavigation);
    return () => window.removeEventListener('keydown', handleKeyboardNavigation);
  }, [activeScene, navigateToScene]);

  return (
    <div className={`experience-shell atmosphere-${Math.floor(activeScene / 3)}`}>
      <div className="experience-canvas" aria-hidden="true">
        <RobotCanvas />
      </div>
      <div className="ambient-wash" aria-hidden="true" />
      <Navigation
        activeScene={activeScene}
        onNavigate={navigateToScene}
        onRestart={() => navigateToScene(0)}
      />
      <ScrollStory activeScene={activeScene} onNavigate={navigateToScene} />
      <div className="scroll-hint" aria-hidden="true">
        <span>SCROLL TO EXPLORE</span>
        <span className="scroll-hint-line" />
      </div>
    </div>
  );
}
