import React from 'react';
import { ArrowDown, ArrowUp, RotateCcw } from 'lucide-react';
import { PRESENTATION_SCENES } from './ScrollStory';

interface NavigationProps {
  activeScene: number;
  onNavigate: (sceneIndex: number) => void;
  onRestart: () => void;
}

const navigationItems = [
  { label: 'Approach', scene: 1 },
  { label: 'Capabilities', scene: 3 },
  { label: 'Projects', scene: 12 },
  { label: 'Contact', scene: 14 },
];

export const Navigation: React.FC<NavigationProps> = ({ activeScene, onNavigate, onRestart }) => {
  const progress = ((activeScene + 1) / PRESENTATION_SCENES.length) * 100;

  return (
    <header className="presentation-header">
      <div className="presentation-nav glass-panel">
        <button className="presentation-wordmark" onClick={onRestart} aria-label="Return to the beginning">
          <span className="brand-signal" />
          <span>BUSINESS SYSTEMS</span>
          <span className="wordmark-divider">/</span>
          <span className="wordmark-subtitle">AI · SOFTWARE · AUTOMATION</span>
        </button>

        <nav className="presentation-links" aria-label="Presentation sections">
          {navigationItems.map((item) => (
            <button key={item.label} onClick={() => onNavigate(item.scene)}>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="presentation-nav-tools">
          <span className="scene-counter" aria-live="polite">
            <strong>{String(activeScene + 1).padStart(2, '0')}</strong>
            <span> / {String(PRESENTATION_SCENES.length).padStart(2, '0')}</span>
          </span>
          <button
            className="nav-step-button"
            aria-label="Previous scene"
            disabled={activeScene === 0}
            onClick={() => onNavigate(Math.max(0, activeScene - 1))}
          >
            <ArrowUp size={15} />
          </button>
          <button
            className="nav-step-button"
            aria-label="Next scene"
            disabled={activeScene === PRESENTATION_SCENES.length - 1}
            onClick={() => onNavigate(Math.min(PRESENTATION_SCENES.length - 1, activeScene + 1))}
          >
            <ArrowDown size={15} />
          </button>
          <button className="nav-restart-button" onClick={onRestart} aria-label="Restart presentation">
            <RotateCcw size={14} />
          </button>
        </div>
        <div className="nav-progress-track" aria-hidden="true">
          <span style={{ width: `${progress}%` }} />
        </div>
      </div>
    </header>
  );
};
