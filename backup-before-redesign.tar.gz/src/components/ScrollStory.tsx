import React, { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Bot,
  Boxes,
  Building2,
  Check,
  ChevronDown,
  ChevronLeft,
  Cpu,
  GraduationCap,
  HeartPulse,
  Layers3,
  Network,
  ShoppingBag,
  Smartphone,
  Workflow,
  X,
  Zap,
} from 'lucide-react';

interface ScrollStoryProps {
  activeScene: number;
  onNavigate: (sceneIndex: number) => void;
}

interface SceneContent {
  id: string;
  marker: string;
  eyebrow: string;
  heading: string;
  description: string;
  type: 'arrival' | 'problems' | 'philosophy' | 'services' | 'workflow' | 'process' | 'ecosystem' | 'example' | 'outcomes' | 'industries' | 'engagement' | 'reasons' | 'projects' | 'promise' | 'finale';
}

const scenes: SceneContent[] = [
  {
    id: 'arrival',
    marker: '01',
    eyebrow: 'A better way forward',
    heading: 'Build smarter. Automate better. Grow faster.',
    description: 'Engineering intelligent digital solutions for modern businesses.',
    type: 'arrival',
  },
  {
    id: 'problem',
    marker: '02',
    eyebrow: 'The challenge',
    heading: 'Work should move forward—not get stuck between systems.',
    description: 'Manual work, scattered information, missed leads, slow processes, repetitive tasks, poor visibility and difficult scaling can make progress harder than it needs to be.',
    type: 'problems',
  },
  {
    id: 'philosophy',
    marker: '03',
    eyebrow: 'Our philosophy',
    heading: 'Start with the business. Build toward what matters.',
    description: 'A clear progression connects the real need to a practical solution, then leaves room for the business to grow.',
    type: 'philosophy',
  },
  {
    id: 'capabilities',
    marker: '04',
    eyebrow: 'What we build',
    heading: 'Technology shaped around the way your business works.',
    description: 'Explore the capabilities in scope. Select a service to see its focus.',
    type: 'services',
  },
  {
    id: 'ai-operations',
    marker: '05',
    eyebrow: 'AI inside business',
    heading: 'Connect the moments from first contact to useful insight.',
    description: 'A connected workflow can carry customer interactions through capture, qualification, follow-up and analytics.',
    type: 'workflow',
  },
  {
    id: 'product-journey',
    marker: '06',
    eyebrow: 'From idea to working product',
    heading: 'A product journey with every step in view.',
    description: 'Discovery through support: bring the right people and technology together at each stage.',
    type: 'process',
  },
  {
    id: 'ecosystem',
    marker: '07',
    eyebrow: 'Connected business ecosystem',
    heading: 'Make the tools you rely on work as one system.',
    description: 'Websites, CRM, ERP, AI assistants, analytics, payments and customer portals can connect through purposeful integrations.',
    type: 'ecosystem',
  },
  {
    id: 'workflow-example',
    marker: '08',
    eyebrow: 'Illustrative example',
    heading: 'See one possible lead workflow in motion.',
    description: 'This fictional example illustrates a process—not a client result or deployment claim.',
    type: 'example',
  },
  {
    id: 'outcomes',
    marker: '09',
    eyebrow: 'Business outcomes',
    heading: 'Build a business that is easier to understand and improve.',
    description: 'Better processes can reduce repetitive effort, improve visibility and make it easier to scale. No performance figures are implied.',
    type: 'outcomes',
  },
  {
    id: 'industries',
    marker: '10',
    eyebrow: 'Industries we serve',
    heading: 'Different industries. Distinct ways of working.',
    description: 'Solutions can be shaped for the context, people and processes of each organization.',
    type: 'industries',
  },
  {
    id: 'engagement',
    marker: '11',
    eyebrow: 'Our engagement model',
    heading: 'Begin with a focused solution. Expand when it makes sense.',
    description: 'A practical starting point can grow into connected automation and broader business transformation over time.',
    type: 'engagement',
  },
  {
    id: 'why-us',
    marker: '12',
    eyebrow: 'How we work',
    heading: 'Technology decisions grounded in business needs.',
    description: 'A thoughtful partnership keeps the problem, implementation and next steps connected.',
    type: 'reasons',
  },
  {
    id: 'projects',
    marker: '13',
    eyebrow: 'Products and projects',
    heading: 'A closer look at selected work.',
    description: 'Open a project to see its purpose. These descriptions do not imply commercial deployment.',
    type: 'projects',
  },
  {
    id: 'promise',
    marker: '14',
    eyebrow: 'Our promise',
    heading: 'A few principles worth building by.',
    description: 'Technology should earn its place in the business.',
    type: 'promise',
  },
  {
    id: 'contact',
    marker: '15',
    eyebrow: 'The next step',
    heading: 'What should we build together?',
    description: 'Build. Automate. Grow. Start a conversation about the business problem you want to solve.',
    type: 'finale',
  },
];

const serviceItems = [
  { title: 'AI-powered business solutions', detail: 'Apply AI to practical workflows, products and decision support.' },
  { title: 'Custom software development', detail: 'Design and build software around a specific business need.' },
  { title: 'ERP systems', detail: 'Bring core operational processes into a connected system.' },
  { title: 'CRM systems', detail: 'Organize customer and lead information around your sales process.' },
  { title: 'Learning Management Systems', detail: 'Support learning programs, content and learner administration.' },
  { title: 'Websites and web applications', detail: 'Create digital experiences and tools for customers or teams.' },
  { title: 'E-commerce platforms', detail: 'Build online storefronts and supporting commerce workflows.' },
  { title: 'Mobile applications and PWAs', detail: 'Make useful business experiences available across devices.' },
  { title: 'Business process automation', detail: 'Reduce repetitive handoffs with carefully designed workflows.' },
  { title: 'AI chatbots and assistants', detail: 'Help people access information and complete common tasks.' },
  { title: 'Data analytics and dashboards', detail: 'Make relevant operational information easier to understand.' },
  { title: 'Business process digitization', detail: 'Move manual processes into clear, trackable digital workflows.' },
  { title: 'Digital transformation', detail: 'Connect technology changes to how the organization operates.' },
];

const projects = [
  {
    name: 'EduPilot',
    category: 'Education and coaching',
    description: 'An education and coaching institute ERP platform.',
    details: 'Project focus: support the operational needs of education and coaching institutes through an ERP platform.',
    icon: GraduationCap,
  },
  {
    name: 'CityTwin Nagpur',
    category: 'Intelligent mobility',
    description: 'An intelligent traffic management and digital twin project.',
    details: 'Project focus: explore intelligent traffic management through a city digital twin concept for Nagpur.',
    icon: Building2,
  },
  {
    name: 'SalonSphere',
    category: 'Salon and spa operations',
    description: 'Multi-branch salon and spa management software.',
    details: 'Project focus: coordinate management needs across multiple salon and spa branches.',
    icon: ShoppingBag,
  },
];

const serviceIcons = [Cpu, Workflow, Boxes, Network, GraduationCap, Layers3, ShoppingBag, Smartphone, Zap, Bot, Network, Workflow, ArrowUpRight];

function FlowLine({ labels }: { labels: string[] }) {
  return (
    <div className="flow-line" aria-label={labels.join(' then ')}>
      {labels.map((label, index) => (
        <React.Fragment key={label}>
          <div className="flow-node">
            <span className="flow-node-index">{String(index + 1).padStart(2, '0')}</span>
            <span>{label}</span>
          </div>
          {index < labels.length - 1 && <span className="flow-connector" aria-hidden="true" />}
        </React.Fragment>
      ))}
    </div>
  );
}

function SceneVisual({
  scene,
  onNavigate,
}: {
  scene: SceneContent;
  onNavigate: (sceneIndex: number) => void;
}) {
  const [expandedService, setExpandedService] = useState<number | null>(null);
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  useEffect(() => {
    if (selectedProject === null) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedProject(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  switch (scene.type) {
    case 'arrival':
      return (
        <div className="scene-visual scene-arrival-visual">
          <div className="arrival-orbit"><span /><span /><span /></div>
          <div className="arrival-caption">
            <span className="live-dot" /> ONE CONNECTED JOURNEY
          </div>
          <button className="scene-cta" onClick={() => onNavigate(1)}>
            Explore the journey <ArrowDown size={16} />
          </button>
        </div>
      );
    case 'problems':
      return (
        <div className="scene-visual">
          <div className="signal-grid">
            {['Manual work', 'Scattered information', 'Missed leads', 'Slow processes', 'Repetitive tasks', 'Poor visibility', 'Difficult scaling'].map((item, index) => (
              <div className="signal-card" key={item} style={{ animationDelay: `${index * 70}ms` }}>
                <span className="signal-mark">{String(index + 1).padStart(2, '0')}</span>
                <span>{item}</span>
                <span className="signal-pulse" />
              </div>
            ))}
          </div>
        </div>
      );
    case 'philosophy':
      return (
        <div className="scene-visual">
          <FlowLine labels={['Understand', 'Strategize', 'Build', 'Automate', 'Grow']} />
          <p className="visual-footnote">A clear sequence, shaped around the business.</p>
        </div>
      );
    case 'services':
      return (
        <div className="scene-visual service-grid">
          {serviceItems.map((service, index) => {
            const Icon = serviceIcons[index];
            const isExpanded = expandedService === index;
            return (
              <button
                className={`service-tile ${isExpanded ? 'service-tile-open' : ''}`}
                key={service.title}
                onClick={() => setExpandedService(isExpanded ? null : index)}
                aria-expanded={isExpanded}
              >
                <span className="service-icon"><Icon size={16} /></span>
                <span className="service-title">{service.title}</span>
                <ChevronDown className="service-chevron" size={14} />
                {isExpanded && <span className="service-detail">{service.detail}</span>}
              </button>
            );
          })}
        </div>
      );
    case 'workflow':
      return (
        <div className="scene-visual">
          <FlowLine labels={['Customer interaction', 'Lead capture', 'Qualification', 'CRM', 'Follow-up', 'Analytics']} />
          <div className="data-flow-caption"><span className="data-flow-beam" /> CONNECTED DATA FLOW</div>
        </div>
      );
    case 'process':
      return (
        <div className="scene-visual process-grid">
          {['Discovery', 'Strategy', 'UX/UI', 'Development', 'AI & automation', 'Testing', 'Deployment', 'Support'].map((stage, index) => (
            <div className="process-step" key={stage}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <strong>{stage}</strong>
              {index < 7 && <ArrowRight size={14} />}
            </div>
          ))}
        </div>
      );
    case 'ecosystem':
      return (
        <div className="scene-visual ecosystem-map">
          <div className="ecosystem-center"><Network size={20} /><span>Connected<br />business</span></div>
          {['Website', 'CRM', 'ERP', 'AI assistant', 'Analytics', 'Payments', 'Customer portal'].map((node, index) => (
            <div className={`ecosystem-node ecosystem-node-${index + 1}`} key={node}>
              <span className="ecosystem-node-dot" />{node}
            </div>
          ))}
          <div className="ecosystem-rings" aria-hidden="true"><span /><span /></div>
        </div>
      );
    case 'example':
      return (
        <div className="scene-visual">
          <div className="illustrative-badge">ILLUSTRATIVE WORKFLOW · NOT A CLIENT RESULT</div>
          <FlowLine labels={['New lead', 'Captured', 'Assigned', 'Follow-up', 'Tracked']} />
          <p className="visual-footnote">One fictional example of a lead moving through a connected process.</p>
        </div>
      );
    case 'outcomes':
      return (
        <div className="scene-visual outcomes-grid">
          {[
            ['Acquire', 'Create clearer paths for new opportunities.'],
            ['Convert', 'Support timely, consistent customer journeys.'],
            ['Automate', 'Reduce repetitive work and handoffs.'],
            ['Optimize', 'Use better visibility to improve processes.'],
          ].map(([title, detail], index) => (
            <div className="outcome-card" key={title}>
              <span>0{index + 1}</span><strong>{title}</strong><p>{detail}</p>
            </div>
          ))}
        </div>
      );
    case 'industries':
      return (
        <div className="scene-visual industry-grid">
          {[
            ['Education', GraduationCap],
            ['Professional services', Workflow],
            ['Retail', ShoppingBag],
            ['E-commerce', Layers3],
            ['Real estate', Building2],
            ['Healthcare', HeartPulse],
            ['Finance', Network],
            ['Manufacturing', Boxes],
            ['Startups and growing businesses', Zap],
          ].map(([name, Icon]) => {
            const IndustryIcon = Icon as typeof Building2;
            return <div className="industry-tile" key={name as string}><IndustryIcon size={17} /><span>{name as string}</span></div>;
          })}
        </div>
      );
    case 'engagement':
      return (
        <div className="scene-visual engagement-grid">
          {[
            ['01', 'Build', 'Start with a focused product or system.'],
            ['02', 'Automate', 'Connect the work that benefits from automation.'],
            ['03', 'Transform', 'Expand the ecosystem as the needs evolve.'],
          ].map(([number, title, detail]) => (
            <div className="engagement-step" key={title}>
              <span>{number}</span><strong>{title}</strong><p>{detail}</p>
            </div>
          ))}
        </div>
      );
    case 'reasons':
      return (
        <div className="scene-visual reason-list">
          {[
            'Business understanding before technology choices',
            'Custom solutions shaped around real processes',
            'AI-first thinking where it adds practical value',
            'End-to-end execution from idea to release',
            'A long-term perspective on what comes next',
          ].map((reason, index) => (
            <div className="reason-row" key={reason}><span>0{index + 1}</span><Check size={16} /><strong>{reason}</strong></div>
          ))}
        </div>
      );
    case 'projects':
      return (
        <>
          <div className="scene-visual project-grid">
            {projects.map((project, index) => {
              const Icon = project.icon;
              return (
                <button className="project-card" key={project.name} onClick={() => setSelectedProject(index)}>
                  <span className="project-icon"><Icon size={19} /></span>
                  <span className="project-category">{project.category}</span>
                  <strong>{project.name}</strong>
                  <span className="project-description">{project.description}</span>
                  <span className="project-open">Explore project <ArrowUpRight size={14} /></span>
                </button>
              );
            })}
          </div>
          {selectedProject !== null && (() => {
            const project = projects[selectedProject];
            const ProjectIcon = project.icon;
            return (
              <div className="project-modal-backdrop" onMouseDown={(event) => {
                if (event.target === event.currentTarget) setSelectedProject(null);
              }}>
                <section className="project-modal glass-panel" role="dialog" aria-modal="true" aria-labelledby="project-modal-title">
                  <button className="modal-close" aria-label="Close project details" onClick={() => setSelectedProject(null)}><X size={18} /></button>
                  <div className="project-modal-visual"><span /><ProjectIcon size={28} /><span /></div>
                  <span className="scene-eyebrow">{project.category}</span>
                  <h3 id="project-modal-title">{project.name}</h3>
                  <p>{project.details}</p>
                  <p className="project-disclaimer">Feature-level specifications and product imagery were not included in the available brief. No commercial deployment or client result is implied.</p>
                </section>
              </div>
            );
          })()}
        </>
      );
    case 'promise':
      return (
        <div className="scene-visual promise-list">
          {[
            'Every feature should solve a problem.',
            'Every automation should save effort.',
            'Every system should create visibility.',
            'Every technology investment should move the business forward.',
          ].map((promise, index) => (
            <div key={promise} className="promise-row"><span>0{index + 1}</span><strong>{promise}</strong></div>
          ))}
        </div>
      );
    case 'finale':
      return (
        <div className="scene-visual finale-visual">
          <div className="finale-mark">BUILD <span>·</span> AUTOMATE <span>·</span> GROW</div>
          <div className="founders">Sanket <span>&</span> Atharva</div>
          <a className="scene-cta" href="mailto:athravasonone7@gmail.com?subject=Let%27s%20build%20together">
            Start a conversation <ArrowUpRight size={16} />
          </a>
          <button className="replay-link" onClick={() => onNavigate(0)}><ChevronLeft size={14} /> Return to the beginning</button>
        </div>
      );
    default:
      return null;
  }
}

export const ScrollStory: React.FC<ScrollStoryProps> = ({ activeScene, onNavigate }) => {
  return (
    <main className="presentation-story">
      {scenes.map((scene, index) => {
        const active = activeScene === index;
        return (
          <section
            className={`presentation-scene scene-${scene.type} ${active ? 'scene-active' : ''}`}
            id={`scene-${scene.id}`}
            data-scene-index={index}
            key={scene.id}
            aria-labelledby={`scene-heading-${scene.id}`}
          >
            <div className="scene-shell">
              <article className="scene-copy glass-panel">
                <div className="scene-meta">
                  <span className="scene-number">{scene.marker} / 15</span>
                  <span className="scene-eyebrow">{scene.eyebrow}</span>
                </div>
                <h1 id={`scene-heading-${scene.id}`} className={index === 0 || index === scenes.length - 1 ? 'scene-heading scene-heading-display' : 'scene-heading'}>
                  {scene.heading}
                </h1>
                <p className="scene-description">{scene.description}</p>
                <SceneVisual scene={scene} onNavigate={onNavigate} />
              </article>
            </div>
          </section>
        );
      })}
    </main>
  );
};

export { scenes as PRESENTATION_SCENES };
