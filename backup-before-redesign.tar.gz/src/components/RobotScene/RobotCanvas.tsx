import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const MODEL_URL = '/models/protector_nemesis__the_fallen_seraph.glb';
const SCENE_COUNT = 15;

const CAMERA_POSITIONS: [number, number, number][] = [
  [0.1, 1.35, 4.9],
  [0.25, 1.35, 4.0],
  [-0.12, 1.48, 3.8],
  [0.15, 1.55, 3.55],
  [0.15, 1.5, 3.7],
  [0.45, 1.25, 4.0],
  [0.1, 1.4, 3.8],
  [-0.2, 1.35, 3.7],
  [0.2, 1.3, 3.8],
  [0.45, 1.5, 4.1],
  [0.1, 1.45, 3.9],
  [-0.1, 1.5, 4.0],
  [0.2, 1.45, 3.7],
  [-0.2, 1.35, 4.1],
  [0.1, 1.3, 4.3],
];

const CAMERA_TARGETS: [number, number, number][] = [
  [0.65, 0.9, 0],
  [0.7, 1.05, 0],
  [0.8, 1.25, 0],
  [0.72, 1.25, 0],
  [0.7, 1.15, 0],
  [0.75, 0.95, 0],
  [0.75, 1.0, 0],
  [0.8, 1.05, 0],
  [0.7, 1.0, 0],
  [0.65, 1.1, 0],
  [0.75, 1.05, 0],
  [0.7, 1.1, 0],
  [0.75, 1.05, 0],
  [0.8, 1.0, 0],
  [0.65, 0.95, 0],
];

function getStoryProgress(): number {
  const scenes = document.querySelectorAll<HTMLElement>('[data-scene-index]');
  const storyPosition = window.scrollY + window.innerHeight * 0.48;
  for (const section of scenes) {
    const top = section.getBoundingClientRect().top + window.scrollY;
    const bottom = top + section.offsetHeight;
    if (storyPosition <= bottom) {
      const index = Number(section.dataset.sceneIndex);
      const localProgress = THREE.MathUtils.clamp((storyPosition - top) / section.offsetHeight, 0, 1);
      return (index + localProgress) / (SCENE_COUNT - 1);
    }
  }
  return 1;
}

function getWaypoint(points: [number, number, number][], progress: number, target: THREE.Vector3): THREE.Vector3 {
  const scaledProgress = progress * (SCENE_COUNT - 1);
  const startIndex = Math.min(Math.floor(scaledProgress), SCENE_COUNT - 2);
  const localProgress = THREE.MathUtils.clamp(scaledProgress - startIndex, 0, 1);
  const easedProgress = localProgress * localProgress * (3 - 2 * localProgress);
  const start = points[startIndex];
  const end = points[startIndex + 1];
  return target.set(
    THREE.MathUtils.lerp(start[0], end[0], easedProgress),
    THREE.MathUtils.lerp(start[1], end[1], easedProgress),
    THREE.MathUtils.lerp(start[2], end[2], easedProgress)
  );
}

function disposeObjectResources(object: THREE.Object3D): void {
  const geometries = new Set<THREE.BufferGeometry>();
  const materials = new Set<THREE.Material>();
  const textures = new Set<THREE.Texture>();
  object.traverse((child) => {
    if (!(child instanceof THREE.Mesh)) return;
    geometries.add(child.geometry);
    const meshMaterials = Array.isArray(child.material) ? child.material : [child.material];
    meshMaterials.forEach((material) => {
      materials.add(material);
      Object.values(material).forEach((value) => {
        if (value instanceof THREE.Texture) textures.add(value);
      });
    });
  });
  geometries.forEach((geometry) => geometry.dispose());
  textures.forEach((texture) => texture.dispose());
  materials.forEach((material) => material.dispose());
}

export const RobotCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;
    container.dataset.modelState = 'loading';

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const extension = probe.getExtension('WEBGL_debug_renderer_info');
      const parameter = extension ? extension.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const rendererName = String(probe.getParameter(parameter));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererName);
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const scene = new THREE.Scene();
    const background = new THREE.Color(0x05070d);
    scene.background = background;
    scene.fog = new THREE.FogExp2(0x05070d, 0.025);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.05, 60);
    camera.position.set(...CAMERA_POSITIONS[0]);
    camera.lookAt(...CAMERA_TARGETS[0]);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: false,
        powerPreference: 'high-performance',
      });
    } catch (error) {
      console.error('Unable to initialize the 3D presentation scene:', error);
      container.setAttribute('data-webgl-unavailable', 'true');
      container.dataset.modelState = 'error';
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = false;
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = environment.texture;
    pmremGenerator.dispose();

    const keyLight = new THREE.DirectionalLight(0xe4efff, 3.1);
    keyLight.position.set(-2.5, 4, 4);
    scene.add(keyLight);

    const cyanLight = new THREE.PointLight(0x37c8ff, 70, 9);
    cyanLight.position.set(1.6, 2.4, 1.8);
    scene.add(cyanLight);

    const violetLight = new THREE.PointLight(0x805bff, 90, 10);
    violetLight.position.set(-2.8, 1.2, -1.5);
    scene.add(violetLight);

    const rimLight = new THREE.DirectionalLight(0x755cff, 2.5);
    rimLight.position.set(1.5, 2.8, -3);
    scene.add(rimLight);

    scene.add(new THREE.HemisphereLight(0x5e7dbb, 0x080a13, 1.25));

    const floorRingMaterial = new THREE.MeshBasicMaterial({
      color: 0x37c8ff,
      transparent: true,
      opacity: 0.42,
      side: THREE.DoubleSide,
    });
    const floorRing = new THREE.Mesh(new THREE.RingGeometry(0.82, 0.84, 96), floorRingMaterial);
    floorRing.rotation.x = -Math.PI / 2;
    floorRing.position.y = -0.635;
    floorRing.scale.set(1, 0.56, 1);
    scene.add(floorRing);

    const innerRing = new THREE.Mesh(
      new THREE.RingGeometry(1.05, 1.065, 96),
      new THREE.MeshBasicMaterial({
        color: 0x8c65ff,
        transparent: true,
        opacity: 0.27,
        side: THREE.DoubleSide,
      })
    );
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.y = -0.63;
    innerRing.scale.set(1, 0.56, 1);
    scene.add(innerRing);

    const robot = new THREE.Group();
    robot.position.set(1.35, -0.65, 0);
    robot.rotation.y = -0.38;
    scene.add(robot);

    let disposed = false;
    let loadedModel: THREE.Group | null = null;
    const loader = new GLTFLoader();
    loader.load(
      MODEL_URL,
      (gltf) => {
        if (disposed) {
          disposeObjectResources(gltf.scene);
          return;
        }

        const bounds = new THREE.Box3().setFromObject(gltf.scene);
        const size = bounds.getSize(new THREE.Vector3());
        const center = bounds.getCenter(new THREE.Vector3());
        if (!Number.isFinite(size.y) || size.y <= 0) {
          container.dataset.modelState = 'error';
          console.error('The supplied GLB has no measurable model height.');
          return;
        }

        const modelScale = 2.8 / size.y;
        const normalizedModel = new THREE.Group();
        normalizedModel.scale.setScalar(modelScale);
        normalizedModel.position.set(
          -center.x * modelScale,
          -bounds.min.y * modelScale,
          -center.z * modelScale
        );
        normalizedModel.add(gltf.scene);
        robot.add(normalizedModel);
        loadedModel = gltf.scene;
        container.dataset.modelState = 'ready';

        if (gltf.animations.length === 0) {
          console.info('The robot GLB has no animation clips; its presentation motion is scroll-driven.');
        }
      },
      (event) => {
        if (event.total > 0) {
          container.style.setProperty('--model-load-progress', `${event.loaded / event.total}`);
        }
      },
      (error) => {
        container.dataset.modelState = 'error';
        console.error('Failed to load the robot GLB:', error);
      }
    );

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const storyProgress = { current: getStoryProgress() };
    const updateStoryProgress = () => {
      storyProgress.current = getStoryProgress();
    };
    window.addEventListener('scroll', updateStoryProgress, { passive: true });
    const cameraPosition = new THREE.Vector3();
    const cameraTarget = new THREE.Vector3();
    const desiredPosition = new THREE.Vector3();
    const desiredTarget = new THREE.Vector3();
    let animationFrame = 0;
    let previousFrameTime = 0;

    const renderFrame = (now: number) => {
      animationFrame = requestAnimationFrame(renderFrame);
      if (reducedMotion.matches && now - previousFrameTime < 100) return;
      const delta = Math.min((now - previousFrameTime) / 1000, 0.05);
      previousFrameTime = now;
      const progress = storyProgress.current;

      getWaypoint(CAMERA_POSITIONS, progress, desiredPosition);
      getWaypoint(CAMERA_TARGETS, progress, desiredTarget);

      const responsiveZoom = camera.aspect < 0.85 ? 1.35 : camera.aspect < 1.2 ? 1.12 : 1;
      desiredPosition.sub(desiredTarget).multiplyScalar(responsiveZoom).add(desiredTarget);
      cameraPosition.copy(desiredPosition);
      camera.position.lerp(cameraPosition, 1 - Math.exp(-5.5 * delta));
      cameraTarget.copy(desiredTarget);
      camera.lookAt(cameraTarget);

      const motion = reducedMotion.matches ? 0 : 1;
      const sceneProgress = progress * (SCENE_COUNT - 1);
      robot.rotation.y = -0.38 + sceneProgress * (Math.PI * 2 / (SCENE_COUNT - 1));
      robot.rotation.x = Math.sin(sceneProgress * 0.55) * 0.018 * motion;
      robot.position.y = -0.65 + Math.sin(sceneProgress * 0.8) * 0.025 * motion;
      robot.position.x = 1.35 + Math.sin(sceneProgress * 0.45) * 0.12;

      const colorShift = (0.56 + Math.sin(progress * Math.PI * 2) * 0.12 + 1) % 1;
      cyanLight.color.setHSL(colorShift, 0.82, 0.58);
      violetLight.color.setHSL((colorShift + 0.12) % 1, 0.78, 0.52);
      rimLight.color.setHSL((colorShift + 0.16) % 1, 0.72, 0.62);
      cyanLight.position.x = 1.7 + Math.sin(progress * Math.PI * 2) * 0.8;
      violetLight.position.x = -2.6 + Math.cos(progress * Math.PI * 2) * 0.6;
      floorRing.rotation.z = progress * Math.PI * 0.8 * motion;
      innerRing.rotation.z = -progress * Math.PI * 0.6 * motion;

      renderer.render(scene, camera);
    };
    animationFrame = requestAnimationFrame(renderFrame);

    const handleResize = () => {
      const nextWidth = container.clientWidth || window.innerWidth;
      const nextHeight = container.clientHeight || window.innerHeight;
      camera.aspect = nextWidth / nextHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(nextWidth, nextHeight);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.75));
    };
    window.addEventListener('resize', handleResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(animationFrame);
      window.removeEventListener('scroll', updateStoryProgress);
      window.removeEventListener('resize', handleResize);
      if (loadedModel) disposeObjectResources(loadedModel);
      floorRing.geometry.dispose();
      floorRingMaterial.dispose();
      innerRing.geometry.dispose();
      (innerRing.material as THREE.Material).dispose();
      environment.texture.dispose();
      keyLight.dispose();
      cyanLight.dispose();
      violetLight.dispose();
      rimLight.dispose();
      scene.clear();
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
      delete container.dataset.modelState;
      container.style.removeProperty('--model-load-progress');
      container.removeAttribute('data-webgl-unavailable');
    };
  }, []);

  return <div ref={mountRef} className="robot-canvas-mount" />;
};
